package com.example.qrcoder;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class activity1 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act1);

    }
}