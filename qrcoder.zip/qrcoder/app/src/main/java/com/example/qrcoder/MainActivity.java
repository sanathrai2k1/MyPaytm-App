package com.example.qrcoder;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MainActivity extends AppCompatActivity {


    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DBHelper mDbHelper = new DBHelper(this);

        ImageView img;
        img = findViewById(R.id.scan);
        img.setOnClickListener(view ->
        {
            scanCode();
        });

        Button btn;
        btn = findViewById(R.id.scan_button);
        btn.setOnClickListener(view ->
        {
            scanCode();
        });

        ImageView img1 = (ImageView) findViewById(R.id.wallet);
        img1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),activity6.class));
            }
        });

        ImageView img2 = (ImageView) findViewById(R.id.Balance);
        img2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),activity2.class));
            }
        });

        ImageView img3 = (ImageView) findViewById(R.id.bank);
        img3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),activity3.class));
            }
        });

        ImageView img4 = (ImageView) findViewById(R.id.mobile);
        img4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),activity4.class));
            }
        });

        ImageView img5 = (ImageView) findViewById(R.id.bhim);
        img5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),activity5.class));
            }
        });


    }

    private void scanCode()
    {

        ScanOptions options = new ScanOptions();
        options.setPrompt("Volume up to flash on");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barLauncher.launch(options);
    }

    private SQLiteOpenHelper mDbHelper;
    ActivityResultLauncher<ScanOptions>barLauncher = registerForActivityResult(new ScanContract(),result ->
    {
        if(result.getContents()!=null)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Result");


            /*String message=result.getContents();
            SQLiteDatabase db = mDbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put(DBHelper.COLUMN_MESSAGE, message);
            db.insert(DBHelper.TABLE_NAME, null, values);
*/

            builder.setMessage(result.getContents());
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener()
            {

                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }).show();



        }
    });


}
